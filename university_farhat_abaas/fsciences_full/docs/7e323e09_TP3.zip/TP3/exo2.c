

/*	TP 3 : Utilisation des mutex pour l'EM	*/


#include <stdio.h>           
#include <stdlib.h>            
// biblioth�que de thread

#define NBTH 10
#define ITER 100000

/* declaration et initialisation d'un Mutex	*/
	pthread_mutex_t Mutex = PTHREAD_MUTEX_INITIALIZER; 
	
/* Initialisation de la variable partag�e */	
	int V = 100;

						// prototype de la fonction executee par les threads 

int main(int argc, char *argv[])
{
						// declaration des identificateurs de threads
    	int i, error;

	printf("La valeur initiale de V est %d\n",V);

/* Creation des threads */
    for (i=0; i<NBTH; i++){
	    error = pthread_create(&th[i], NULL, mult, (void*)i);
		    if (error !=0){ 
				printf ("erreur lors de la creation de thread %d\n",i); 
				exit(1);	
			}
	}		
	
/* attendre la fin des threads */	 
    for (i=0; i<NBTH; i++)
	    
	
	
/* destruction du mutex */
	pthread_mutex_destroy(&Mutex);

	printf("La valeur finale de V est %d\n",V);
	
}	// fin du main

void *mult(void *arg) {
	int i, j;
	j = (int)arg;
	printf("Debut du Thread %d  \n",j);

	//coml�tez le pgm
		
	pthread_exit(NULL);
	}				


